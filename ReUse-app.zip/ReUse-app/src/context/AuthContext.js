import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as api from '../services/api';
import { saveSession, getTokens, getStoredUser, updateStoredUser, clearSession } from '../services/session';
import { clearCache } from '../services/cache';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // restaurando sessão ao abrir o app

  // Ao abrir o app: restaura a sessão salva e valida o token (ou usa o usuário salvo se estiver offline).
  useEffect(() => {
    (async () => {
      try {
        const tokens = await getTokens();
        const stored = await getStoredUser();
        if (!tokens || !stored) return;
        try {
          const me = await api.fetchMe();
          const full = { ...stored, ...me };
          await updateStoredUser(full);
          setUser(full);
        } catch (e) {
          if (e.status === 401 || e.status === 403 || e.message === 'Sessão expirada') await clearSession();
          else setUser(stored); // sem rede: mantém a sessão local
        }
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const signIn = useCallback(async (username, password) => {
    const data = await api.login(username, password);
    const { accessToken, refreshToken, ...profile } = data;
    await saveSession({ accessToken, refreshToken }, profile);
    setUser(profile);
  }, []);

  const signOut = useCallback(async () => {
    await clearSession();
    await clearCache();
    setUser(null);
  }, []);

  return <AuthContext.Provider value={{ user, loading, signIn, signOut }}>{children}</AuthContext.Provider>;
}
