import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, Image, TextInput, TouchableOpacity, RefreshControl, ActivityIndicator, StyleSheet, ScrollView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { getItems, searchItems, getCategories, getItemsByCategory } from '../services/api';
import { colors } from '../theme';

const SOURCE_LABEL = { cache: 'Dados do cache local', network: 'Dados atualizados', 'offline-cache': 'Modo offline: exibindo dados salvos' };

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState(null);
  const [query, setQuery] = useState('');
  const [source, setSource] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async (force = false) => {
    setError('');
    try {
      let res;
      if (query.trim().length >= 2) res = await searchItems(query.trim());
      else if (category) res = await getItemsByCategory(category);
      else res = await getItems({ force });
      setItems(res.data.products || []);
      setSource(res.source);
    } catch (e) { setError('Não foi possível carregar os itens.'); }
    finally { setLoading(false); setRefreshing(false); }
  }, [query, category]);

  useEffect(() => { getCategories().then((r) => setCategories(r.data)).catch(() => {}); }, []);
  useEffect(() => { const t = setTimeout(load, 350); return () => clearTimeout(t); }, [load]);

  return (
    <View style={s.container}>
      <View style={s.header}>
        <Text style={s.hello}>Olá, {user?.firstName}!</Text>
        <View style={s.row}>
          <TouchableOpacity onPress={() => navigation.navigate('NewItem')}><Text style={s.link}>+ Novo item</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Profile')}><Text style={s.link}>Perfil</Text></TouchableOpacity>
        </View>
      </View>
      <TextInput style={s.search} placeholder="Buscar itens..." value={query} onChangeText={setQuery} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.chips}>
        <Chip label="Todos" active={!category} onPress={() => setCategory(null)} />
        {categories.slice(0, 12).map((c) => (
          <Chip key={c.slug} label={c.name} active={category === c.slug} onPress={() => setCategory(c.slug)} />
        ))}
      </ScrollView>
      {!!source && <Text style={[s.badge, source === 'offline-cache' && { color: colors.danger }]}>{SOURCE_LABEL[source]}</Text>}
      {loading ? <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} size="large" /> : (
        <FlatList
          data={items}
          keyExtractor={(i) => String(i.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(true); }} />}
          ListEmptyComponent={<Text style={s.empty}>{error || 'Nenhum item encontrado.'}</Text>}
          renderItem={({ item }) => (
            <TouchableOpacity style={s.card} onPress={() => navigation.navigate('ItemDetail', { id: item.id, title: item.title })}>
              <Image source={{ uri: item.thumbnail }} style={s.thumb} />
              <View style={{ flex: 1 }}>
                <Text style={s.title} numberOfLines={1}>{item.title}</Text>
                <Text style={s.desc} numberOfLines={2}>{item.description}</Text>
                <Text style={s.points}>{Math.round(item.price * 10)} pontos</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}
const Chip = ({ label, active, onPress }) => (
  <TouchableOpacity onPress={onPress} style={[s.chip, active && s.chipActive]}>
    <Text style={{ color: active ? '#fff' : colors.primary, fontSize: 12 }}>{label}</Text>
  </TouchableOpacity>
);
const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, padding: 16, paddingTop: 48 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  row: { flexDirection: 'row', gap: 16 }, hello: { fontSize: 20, fontWeight: '700', color: colors.text },
  link: { color: colors.primary, fontWeight: '600' },
  search: { backgroundColor: '#fff', borderRadius: 10, padding: 12, borderWidth: 1, borderColor: '#DDD', marginBottom: 10 },
  chips: { maxHeight: 40, marginBottom: 6 },
  chip: { borderWidth: 1, borderColor: colors.primary, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6, marginRight: 8, height: 32 },
  chipActive: { backgroundColor: colors.primary },
  badge: { fontSize: 11, color: colors.muted, marginVertical: 6 },
  card: { flexDirection: 'row', backgroundColor: colors.card, borderRadius: 12, padding: 10, marginBottom: 10, gap: 10, elevation: 1 },
  thumb: { width: 76, height: 76, borderRadius: 8, backgroundColor: colors.light },
  title: { fontWeight: '700', color: colors.text }, desc: { color: colors.muted, fontSize: 12, marginTop: 2 },
  points: { color: colors.primary, fontWeight: '700', marginTop: 4 }, empty: { textAlign: 'center', marginTop: 40, color: colors.muted },
});
