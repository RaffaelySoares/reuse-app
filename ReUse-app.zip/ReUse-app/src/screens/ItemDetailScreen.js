import React, { useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import { getItem } from '../services/api';
import { colors } from '../theme';

export default function ItemDetailScreen({ route }) {
  const [item, setItem] = useState(null);
  const [source, setSource] = useState('');
  const [error, setError] = useState('');
  useEffect(() => {
    getItem(route.params.id).then((r) => { setItem(r.data); setSource(r.source); }).catch(() => setError('Não foi possível carregar o item.'));
  }, [route.params.id]);

  if (error) return <Text style={s.error}>{error}</Text>;
  if (!item) return <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} size="large" />;
  return (
    <ScrollView style={s.container}>
      <Image source={{ uri: item.images?.[0] || item.thumbnail }} style={s.image} resizeMode="contain" />
      <Text style={s.title}>{item.title}</Text>
      <Text style={s.points}>{Math.round(item.price * 10)} pontos · Estoque: {item.stock}</Text>
      <Text style={s.meta}>Categoria: {item.category}  |  Avaliação: {item.rating}</Text>
      <Text style={s.desc}>{item.description}</Text>
      {!!item.reviews?.length && <Text style={s.section}>Avaliações</Text>}
      {item.reviews?.map((r, i) => (<View key={i} style={s.review}><Text style={{ fontWeight: '600' }}>{r.reviewerName} ({r.rating}/5)</Text><Text>{r.comment}</Text></View>))}
      <Text style={s.badge}>{source === 'cache' ? 'Dados do cache local' : source === 'offline-cache' ? 'Modo offline' : 'Dados atualizados'}</Text>
    </ScrollView>
  );
}
const s = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: colors.bg }, image: { width: '100%', height: 240, backgroundColor: '#fff', borderRadius: 12 },
  title: { fontSize: 22, fontWeight: '800', marginTop: 12, color: colors.text }, points: { color: colors.primary, fontWeight: '700', marginTop: 4 },
  meta: { color: colors.muted, marginTop: 4 }, desc: { marginTop: 12, lineHeight: 20 }, section: { fontWeight: '700', marginTop: 16, fontSize: 16 },
  review: { backgroundColor: '#fff', padding: 10, borderRadius: 8, marginTop: 8 }, badge: { marginVertical: 16, fontSize: 11, color: colors.muted }, error: { margin: 24, color: colors.danger },
});
