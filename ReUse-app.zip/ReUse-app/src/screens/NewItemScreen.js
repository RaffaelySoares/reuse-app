import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAddressByCep } from '../services/api';
import { colors } from '../theme';

export default function NewItemScreen({ navigation }) {
  const [form, setForm] = useState({ title: '', description: '', cep: '', street: '', district: '', city: '', uf: '' });
  const [msg, setMsg] = useState('');
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  async function onCepBlur() {
    if (form.cep.replace(/\D/g, '').length !== 8) return;
    try {
      const { data, source } = await getAddressByCep(form.cep);
      setForm((f) => ({ ...f, street: data.logradouro, district: data.bairro, city: data.localidade, uf: data.uf }));
      setMsg(source === 'network' ? 'Endereço encontrado.' : 'Endereço carregado do cache.');
    } catch (e) { setMsg(e.message === 'Network request failed' ? 'Sem conexão para buscar o CEP.' : e.message); }
  }

  async function onSave() {
    if (!form.title || !form.city) return Alert.alert('Atenção', 'Informe o título e um CEP válido.');
    const raw = await AsyncStorage.getItem('@reuse:myItems');
    const list = raw ? JSON.parse(raw) : [];
    list.unshift({ ...form, id: Date.now() });
    await AsyncStorage.setItem('@reuse:myItems', JSON.stringify(list));
    Alert.alert('Pronto!', 'Item cadastrado para reuso.', [{ text: 'OK', onPress: () => navigation.goBack() }]);
  }

  return (
    <ScrollView style={s.container}>
      <Text style={s.label}>Título</Text><TextInput style={s.input} value={form.title} onChangeText={set('title')} />
      <Text style={s.label}>Descrição</Text><TextInput style={[s.input, { height: 80 }]} multiline value={form.description} onChangeText={set('description')} />
      <Text style={s.label}>CEP de retirada</Text>
      <TextInput style={s.input} keyboardType="number-pad" maxLength={9} value={form.cep} onChangeText={set('cep')} onBlur={onCepBlur} placeholder="09720-000" />
      {!!msg && <Text style={s.msg}>{msg}</Text>}
      <Text style={s.label}>Rua</Text><TextInput style={s.input} value={form.street} onChangeText={set('street')} />
      <Text style={s.label}>Bairro</Text><TextInput style={s.input} value={form.district} onChangeText={set('district')} />
      <Text style={s.label}>Cidade / UF</Text><TextInput style={s.input} value={form.city ? `${form.city} / ${form.uf}` : ''} editable={false} />
      <TouchableOpacity style={s.button} onPress={onSave}><Text style={s.buttonText}>Salvar item</Text></TouchableOpacity>
    </ScrollView>
  );
}
const s = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: colors.bg }, label: { fontWeight: '600', marginTop: 10, marginBottom: 4 },
  input: { backgroundColor: '#fff', borderRadius: 10, padding: 12, borderWidth: 1, borderColor: '#DDD' }, msg: { color: colors.muted, fontSize: 12, marginTop: 4 },
  button: { backgroundColor: colors.primary, padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 20, marginBottom: 40 }, buttonText: { color: '#fff', fontWeight: '700' },
});
