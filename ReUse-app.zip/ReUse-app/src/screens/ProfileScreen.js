import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { cachedFetch, clearCache } from '../services/cache';
import { fetchMe } from '../services/api';
import { colors } from '../theme';

export default function ProfileScreen() {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState(user);
  const [source, setSource] = useState('');
  useEffect(() => {
    cachedFetch(`profile:${user.id}`, fetchMe, { ttl: 60 * 60 * 1000 })
      .then((r) => { setProfile({ ...user, ...r.data }); setSource(r.source); }).catch(() => {});
  }, [user]);

  return (
    <View style={s.container}>
      <Image source={{ uri: profile.image }} style={s.avatar} />
      <Text style={s.name}>{profile.firstName} {profile.lastName}</Text>
      <Text style={s.muted}>@{profile.username} · {profile.email}</Text>
      {!!source && <Text style={s.badge}>Perfil: {source === 'network' ? 'atualizado agora' : 'cache local'}</Text>}
      <TouchableOpacity style={s.secondary} onPress={async () => { const n = await clearCache(); Alert.alert('Cache limpo', `${n} registros removidos.`); }}>
        <Text style={{ color: colors.primary, fontWeight: '600' }}>Limpar cache local</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.button} onPress={signOut}><Text style={s.buttonText}>Sair</Text></TouchableOpacity>
    </View>
  );
}
const s = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', padding: 24, backgroundColor: colors.bg }, avatar: { width: 96, height: 96, borderRadius: 48, backgroundColor: colors.light, marginTop: 24 },
  name: { fontSize: 22, fontWeight: '800', marginTop: 12 }, muted: { color: colors.muted, marginTop: 4 }, badge: { color: colors.muted, fontSize: 11, marginTop: 8 },
  secondary: { borderWidth: 1, borderColor: colors.primary, padding: 12, borderRadius: 10, marginTop: 32, width: '100%', alignItems: 'center' },
  button: { backgroundColor: colors.danger, padding: 14, borderRadius: 10, marginTop: 12, width: '100%', alignItems: 'center' }, buttonText: { color: '#fff', fontWeight: '700' },
});
