// Consumo de APIs externas: DummyJSON (autenticação e itens) e ViaCEP (endereço).
import { getTokens, saveSession, getStoredUser } from './session';
import { cachedFetch } from './cache';

const DUMMY = 'https://dummyjson.com';
const VIACEP = 'https://viacep.com.br/ws';
const SESSION_MINUTES = 30;

async function json(res) {
  if (!res.ok) {
    let msg = `Erro ${res.status}`;
    try { msg = (await res.json()).message || msg; } catch {}
    const err = new Error(msg); err.status = res.status; throw err;
  }
  return res.json();
}

// ---------- Autenticação ----------
export async function login(username, password) {
  return json(await fetch(`${DUMMY}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, expiresInMins: SESSION_MINUTES }),
  }));
}

async function refreshSession() {
  const tokens = await getTokens();
  if (!tokens?.refreshToken) throw new Error('Sessão expirada');
  const data = await json(await fetch(`${DUMMY}/auth/refresh`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken: tokens.refreshToken, expiresInMins: SESSION_MINUTES }),
  }));
  await saveSession({ accessToken: data.accessToken, refreshToken: data.refreshToken || tokens.refreshToken });
  return data.accessToken;
}

// Requisição autenticada: envia o token e, se der 401, renova o token e tenta de novo.
async function authFetch(path) {
  const tokens = await getTokens();
  const call = (token) => fetch(`${DUMMY}${path}`, { headers: { Authorization: `Bearer ${token}` } });
  let res = await call(tokens?.accessToken);
  if (res.status === 401 || res.status === 403) {
    const newToken = await refreshSession();
    res = await call(newToken);
  }
  return json(res);
}

export const fetchMe = () => authFetch('/auth/me');

// ---------- Itens (produtos da DummyJSON representam itens para reuso) ----------
export const getItems = (opts) =>
  cachedFetch('items:list', () => authFetch('/products?limit=30&select=id,title,description,price,category,thumbnail,rating,brand,stock'), { ttl: 10 * 60 * 1000, ...opts });

export const searchItems = (q) =>
  cachedFetch(`items:search:${q.toLowerCase()}`, () => authFetch(`/products/search?q=${encodeURIComponent(q)}&limit=30`), { ttl: 5 * 60 * 1000 });

export const getCategories = (opts) =>
  cachedFetch('items:categories', () => authFetch('/products/categories'), { ttl: 24 * 60 * 60 * 1000, ...opts });

export const getItemsByCategory = (slug) =>
  cachedFetch(`items:category:${slug}`, () => authFetch(`/products/category/${slug}?limit=30`), { ttl: 10 * 60 * 1000 });

export const getItem = (id, opts) =>
  cachedFetch(`items:detail:${id}`, () => authFetch(`/products/${id}`), { ttl: 30 * 60 * 1000, ...opts });

// ---------- Endereço por CEP (ViaCEP) ----------
export async function getAddressByCep(cepRaw) {
  const cep = String(cepRaw).replace(/\D/g, '');
  if (cep.length !== 8) throw new Error('CEP deve ter 8 dígitos');
  return cachedFetch(`cep:${cep}`, async () => {
    const data = await json(await fetch(`${VIACEP}/${cep}/json/`));
    if (data.erro) throw new Error('CEP não encontrado');
    return data;
  }, { ttl: 30 * 24 * 60 * 60 * 1000 });
}

export { getStoredUser };
