// Cache local com TTL (AsyncStorage). Estratégia: usa o cache se estiver "fresco";
// senão busca na rede; se a rede falhar, devolve o cache vencido (modo offline).
import AsyncStorage from '@react-native-async-storage/async-storage';

const PREFIX = '@reuse:cache:';

export async function setCache(key, data) {
  await AsyncStorage.setItem(PREFIX + key, JSON.stringify({ ts: Date.now(), data }));
}

export async function getCache(key, ttlMs) {
  const raw = await AsyncStorage.getItem(PREFIX + key);
  if (!raw) return null;
  try {
    const { ts, data } = JSON.parse(raw);
    return { data, ts, fresh: ttlMs ? Date.now() - ts < ttlMs : true };
  } catch {
    return null;
  }
}

export async function clearCache() {
  const keys = await AsyncStorage.getAllKeys();
  const mine = keys.filter((k) => k.startsWith(PREFIX));
  if (mine.length) await AsyncStorage.multiRemove(mine);
  return mine.length;
}

// Retorna { data, source: 'cache' | 'network' | 'offline-cache', ts }
export async function cachedFetch(key, fetcher, { ttl = 5 * 60 * 1000, force = false } = {}) {
  const cached = await getCache(key, ttl);
  if (cached && cached.fresh && !force) return { data: cached.data, source: 'cache', ts: cached.ts };
  try {
    const data = await fetcher();
    await setCache(key, data);
    return { data, source: 'network', ts: Date.now() };
  } catch (err) {
    if (cached) return { data: cached.data, source: 'offline-cache', ts: cached.ts };
    throw err;
  }
}
