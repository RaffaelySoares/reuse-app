// Sessão do usuário: tokens no SecureStore (criptografado) e dados do usuário no AsyncStorage.
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TOKENS = 'reuse_tokens';
const USER = '@reuse:user';

export async function saveSession({ accessToken, refreshToken }, user) {
  await SecureStore.setItemAsync(TOKENS, JSON.stringify({ accessToken, refreshToken }));
  if (user) await AsyncStorage.setItem(USER, JSON.stringify(user));
}
export async function getTokens() {
  const raw = await SecureStore.getItemAsync(TOKENS);
  return raw ? JSON.parse(raw) : null;
}
export async function getStoredUser() {
  const raw = await AsyncStorage.getItem(USER);
  return raw ? JSON.parse(raw) : null;
}
export async function updateStoredUser(user) {
  await AsyncStorage.setItem(USER, JSON.stringify(user));
}
export async function clearSession() {
  await SecureStore.deleteItemAsync(TOKENS);
  await AsyncStorage.removeItem(USER);
}
