export const colors = { primary: '#2E7D32', light: '#E8F5E9', text: '#1B1B1B', muted: '#6B6B6B', danger: '#C62828', card: '#FFFFFF', bg: '#F5F7F5' };
